<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Corona Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../assetsadmin/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../assetsadmin/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="../assetsadmin/vendors/jvectormap/jquery-jvectormap.css">
  <link rel="stylesheet" href="../assetsadmin/vendors/flag-icon-css/css/flag-icon.min.css">
  <link rel="stylesheet" href="../assetsadmin/vendors/owl-carousel-2/owl.carousel.min.css">
  <link rel="stylesheet" href="../assetsadmin/vendors/owl-carousel-2/owl.theme.default.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="../assetsadmin/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="../assetsadmin/images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_sidebar.html -->
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
      <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
        <a class="sidebar-brand brand-logo" href="index.html"><img src="{{ asset('assetsadmin/images/logo.svg') }}" alt="logo" /></a>
        <a class="sidebar-brand brand-logo-mini" href="index.html"><img src="{{ asset('assetsadmin/images/logo-mini.svg') }}"
            alt="logo" /></a>
      </div>
      <ul class="nav">
        <li class="nav-item profile">
          <div class="profile-desc">
            <div class="profile-pic">
              <div class="profile-name">
                <h5 class="mb-0 font-weight-normal">{{ auth()->user()->username }}</h5>
                <span>{{ auth()->user()->role }}</span>
              </div>
            </div>
          </div>
        </li>
        <li class="nav-item nav-category">
          <span class="nav-link">Navigation</span>
        </li>
        <li class="nav-item menu-items">
          <a class="nav-link" href="{{ route('admin.dashboard') }}">
            <span class="menu-icon">
              <i class="mdi mdi-speedometer"></i>
            </span>
            <span class="menu-title">Dashboard</span>
          </a>
        </li>
        <li class="nav-item menu-items">
          <a class="nav-link" href="{{ route('admin.menu.index') }}">
            <span class="menu-icon">
              <i class="mdi mdi-speedometer"></i>
            </span>
            <span class="menu-title">Menu</span>
          </a>
        </li>
        <li class="nav-item menu-items active">
          <a class="nav-link" href="{{ route('admin.chef.index') }}">
            <span class="menu-icon">
              <i class="mdi mdi-speedometer"></i>
            </span>
            <span class="menu-title">Chef</span>
          </a>
        </li>
        <li class="nav-item menu-items">
          <a class="nav-link"
            href="{{ url('/') }}">
            <span class="menu-icon">
              <i class="mdi mdi-file-document-box"></i>
            </span>
            <span class="menu-title">Website</span>
          </a>
        </li>
      </ul>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar p-0 fixed-top d-flex flex-row">
        <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <ul class="navbar-nav w-100">
            <li class="nav-item w-100">
              <form class="nav-link mt-2 mt-md-0 d-none d-lg-flex search">
                <input type="text" class="form-control" placeholder="Search products">
              </form>
            </li>
          </ul>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item dropdown">
              <a class="nav-link" id="profileDropdown" href="#" data-toggle="dropdown">
                <div class="navbar-profile">
                  <p class="mb-0 d-none d-sm-block navbar-profile-name">{{ auth()->user()->username }}</p>
                  <i class="mdi mdi-menu-down d-none d-sm-block"></i>
                </div>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list"
                aria-labelledby="profileDropdown">
                <h6 class="p-3 mb-0">Profile</h6>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-dark rounded-circle">
                      <i class="mdi mdi-logout text-danger"></i>
                    </div>
                  </div>
                  <div class="preview-item-content">
                    <form id="logout" action="{{ route('login.logout') }}" method="POST">
                    @csrf
                    <button type="submit" class="preview-subject mb-1 btn btn-danger">Log out</button>
                    </form>
                  </div>
                </a>
              </div>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
            data-toggle="offcanvas">
            <span class="mdi mdi-format-line-spacing"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-xl-12 col-sm-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <div class="card-title">List Chef</div>
                    <div>
                        <a href="{{ route('admin.chef.create') }}" class="btn btn-primary mb-3 py-3">+ Tambah Chef</a>
                    </div>

                    @if (Session::has('success'))
                        <div class="alert alert-primary">
                            {{ Session::get('success') }}
                        </div>
                    @endif

                  <div class="row">
                    <div class="col-12">
                        <table class="table text-center">
                            <thead>
                              <tr>
                                <th scope="col">#</th>
                                <th scope="col">Gambar</th>
                                <th scope="col">Nama Chef</th>
                                <th scope="col">Posisi</th>
                                <th scope="col">Aksi</th>
                              </tr>
                            </thead>
                            <tbody>
                                @foreach ($chefs as $c)
                                <tr>
                                  <th scope="row">{{ $loop->iteration }}</th>
                                  <td>
                                    <img src="{{ asset("asset-gambar/$c->gambar") }}" alt="" class="img-fluid">
                                  </td>
                                  <td>{{ $c->nama_chef }}</td>
                                  <td>{{ $c->posisi }}</td>
                                  <td>
                                    <a href="{{ route('admin.chef.edit', $c->id) }}" class="btn btn-primary px-3">Edit</a>
                                    <form onsubmit="return confirm('Yakin akan menghapus data ini?')" action="{{ route('admin.chef.delete', $c->id) }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    @method('DELETE')
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>

                                  </td>
                                </tr>
                                @endforeach
                                
                            </tbody>
                          </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © bootstrapdash.com
              2020</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> Free <a
                href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">Bootstrap admin
                templates</a> from Bootstrapdash.com</span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>


  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../assetsadmin/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="../assetsadmin/vendors/chart.js/Chart.min.js"></script>
  <script src="../assetsadmin/vendors/progressbar.js/progressbar.min.js"></script>
  <script src="../assetsadmin/vendors/jvectormap/jquery-jvectormap.min.js"></script>
  <script src="../assetsadmin/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
  <script src="../assetsadmin/vendors/owl-carousel-2/owl.carousel.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="../assetsadmin/js/off-canvas.js"></script>
  <script src="../assetsadmin/js/hoverable-collapse.js"></script>
  <script src="../assetsadmin/js/misc.js"></script>
  <script src="../assetsadmin/js/settings.js"></script>
  <script src="../assetsadmin/js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page -->
  <script src="../assetsadmin/js/dashboard.js"></script>
  <!-- End custom js for this page -->
</body>

</html>