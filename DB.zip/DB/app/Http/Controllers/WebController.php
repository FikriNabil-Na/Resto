<?php

namespace App\Http\Controllers;

use App\Models\chef;
use App\Models\menu;
use App\Models\booking;
use Illuminate\Http\Request;

class WebController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $menus = menu::all();
        $chefs = chef::all();
        return view('index', compact('menus', 'chefs'));
    }

    public function booking(Request $request){
        $validated = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'no' => 'required',
            'tanggal' => 'required',
            'time' => 'required',
            'message' => 'nullable',
        ]);

        $validated['message'] = filled($validated['message']) ? $validated['message'] :'-';

        booking::create($validated);
        return redirect()->route('show');
    }

    public function adminBooking(){
        $bookings = booking::all();
        return view('admin.booking.index', compact('bookings'));
    }

}