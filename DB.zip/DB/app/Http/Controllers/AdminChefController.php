<?php

namespace App\Http\Controllers;

use App\Models\chef;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class AdminChefController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $chefs = chef::all();
        return view('admin.chef.index', compact('chefs'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.chef.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_chef' => 'required',
            'posisi' => 'required',
            'gambar' => 'required',
        ]);

        $imageName = $request->file('gambar')->hashName();
        $validated['gambar'] = $imageName;
        $directory = public_path() . '/asset-gambar';
        $request->file('gambar')->move($directory, $imageName);

        chef::create($validated);
        return redirect()->route('admin.chef.index')->with('success', 'Data berhasil ditambahkan!');

    }

    /**
     * Display the specified resource.
     */
    public function show(chef $chef)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(chef $chef, String $id)
    {
        $chefs = chef::find($id);
        return view('admin.chef.edit', compact('chefs'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, String $id)
    {
        $validated = $request->validate([
            'nama_chef' => 'required',
            'posisi' => 'required',
            'gambar' => 'required',
        ]);

        $chefs = chef::find($id);

        File::delete(public_path() . "/asset-gambar/$chefs->gambar");

        $imageName = $request->file('gambar')->hashName();
        $validated['gambar'] = $imageName;
        $directory = public_path() . '/asset-gambar';
        $request->file('gambar')->move($directory, $imageName);
        $chefs->update($validated);

        return redirect()->route('admin.chef.index')->with('success', 'Data berhasil diedit!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(String $id)
    {
        $chefs = chef::find($id);
        File::delete(public_path() . "/asset-gambar/$chefs->gambar");
        $chefs->delete();

        return redirect()->route('admin.chef.index')->with('success', 'Data berhasil dihapus!');
    }
}