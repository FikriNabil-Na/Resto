<?php

namespace App\Http\Controllers;

use App\Models\booking;
use Illuminate\Http\Request;

class ProofBookingController extends Controller
{
    public function index(){
        $bookings = booking::latest()->paginate(1);
        return view('show', compact('bookings'));
    }

}